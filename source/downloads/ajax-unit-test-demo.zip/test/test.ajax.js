import axios from 'axios'
import { expect } from 'chai'

describe('Testing about geting the repositories that stars greater than 200000', function () {
  const apiUrl = 'https://api.github.com/search/repositories'

  let res = null

  before(async function () {
    res = await axios.get(apiUrl, {
      params: {
        q: 'stars:>200000'
      }
    }).then(res => res.data)
  })

  describe('Check the response data', function () {
    it('Should be an object', function () {
      expect(res).to.be.a('object')
    })

    it('Should have property total_count', function () {
      expect(res).to.have.property('total_count')
    })

    it('Should have property items', function () {
      expect(res).to.have.property('items')
    })

    describe('Check the property total_count & items', function () {
      it('Should be a number', function () {
        expect(res.total_count).to.be.a('number')
      })

      it('Should be a array', function () {
        expect(res.items).to.be.a('array')
      })

      it('The length of items should equal total_count', function () {
        expect(res.items).to.be.a('array')
      })
    })
  })
})
